curl -H "Host: myhost.org/api/r/x/w/m/l?key=password" -H "AddCustomRequestParamter: id" -s -X GET http://localhost:8080
curl -H "Host: petman.myhost.org/api/r/x/w/m/l?key=password" -H "AddCustomRequestParamter: id" -s -X GET http://localhost:8080


curl -H "Host: myhost.org/api/r/x/w/m/l?key=password" -H "AddCustomRequestParamter: id" -s -X GET https://dev.zeineldin.link/
