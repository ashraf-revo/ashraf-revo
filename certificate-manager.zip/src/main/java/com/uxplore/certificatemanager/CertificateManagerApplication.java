package com.uxplore.certificatemanager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.regions.providers.AwsRegionProvider;
import software.amazon.awssdk.services.s3.S3Client;

@SpringBootApplication
public class CertificateManagerApplication {
    public static void main(String[] args) {
        SpringApplication.run(CertificateManagerApplication.class, args);
    }

    @Bean
    public AwsRegionProvider awsRegionProvider() {
        return () -> Region.EU_CENTRAL_1;
    }

    @Bean
    public S3Client s3Client() {
        return S3Client.builder().region(Region.EU_CENTRAL_1).build();
    }
}
