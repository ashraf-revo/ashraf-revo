package com.uxplore.certificatemanager.controllor;

import com.uxplore.certificatemanager.domain.CertificateInfo;
import com.uxplore.certificatemanager.domain.DomainRequest;
import com.uxplore.certificatemanager.domain.OrderChallenges;
import com.uxplore.certificatemanager.service.AcmeManagerService;
import com.uxplore.certificatemanager.service.S3Service;
import org.shredzone.acme4j.Order;
import org.shredzone.acme4j.Status;
import org.shredzone.acme4j.exception.AcmeException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.nio.file.Paths;
import java.util.Map;

import static com.uxplore.certificatemanager.service.impl.AcmeManagerServiceImpl.getChallenges;

@RestController
@RequestMapping("api/acm")
public class AcmController {
    @Autowired
    private AcmeManagerService acmeManagerService;
    @Autowired
    private S3Service s3Service;

    /*
    *.appcalc.net
    appcalc.net
    *.uxplore.net
    uxplore.net
    www.uxplore.net
    uxb.uxplore.net
    backend.uxplore.net
    */
    @PostMapping("order")
    public OrderChallenges order(@RequestBody DomainRequest domainRequest) throws AcmeException, IOException {
        Order order = acmeManagerService.order(domainRequest);
        return new OrderChallenges(order.getLocation(), getChallenges(domainRequest, order));
    }


    @PostMapping("validate")
    public Map.Entry<String, Status> validate(@RequestBody DomainRequest domainRequest, @RequestParam(value = "type",
            defaultValue = "dns-01") String type) throws AcmeException {
        return acmeManagerService.validate(domainRequest.getLocation(), type);
    }

    @PostMapping("generate")
    public CertificateInfo generate(@RequestBody DomainRequest domainRequest, @RequestParam(value =
            "type", defaultValue = "dns-01") String type) throws AcmeException, IOException {
        Map.Entry<String, Status> validate = acmeManagerService.validate(domainRequest.getLocation(), type);
        if (validate.getValue() == Status.VALID) {
            return acmeManagerService.generate(domainRequest, domainRequest.getLocation(),
                    (file, s) -> s3Service.uploadFile(file, s));
        }
        return CertificateInfo.from(domainRequest, validate.getValue().name());
    }

    @PostMapping("info")
    public CertificateInfo info(@RequestBody DomainRequest domainRequest) {
        return acmeManagerService.info(domainRequest);
    }


    @PostMapping("domain-file")
    public ResponseEntity<InputStreamResource> getDomainFile(@RequestBody DomainRequest domainRequest) {
        return download(domainRequest);
    }

    private ResponseEntity<InputStreamResource> download(DomainRequest domainRequest) {
        String fileName = Paths.get(domainRequest.getDomain().hashCode() + "", domainRequest.getFile()).toString();
        InputStreamResource body = new InputStreamResource(s3Service.getFile(fileName));
        return ResponseEntity.ok().headers(httpHeaders -> httpHeaders.add(HttpHeaders.CONTENT_DISPOSITION,
                "attachment;filename=" + domainRequest.getFile())).body(body);
    }
}
