package com.uxplore.certificatemanager.domain;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.Setter;
import org.shredzone.acme4j.Certificate;

import java.math.BigInteger;
import java.util.Date;
import java.util.Map;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CertificateInfo {
    private final String status;
    private final DomainRequest domainRequest;
    private Date notAfter;
    private Date notBefore;
    private BigInteger serialNumber;
    private Integer version;
    private String sigAlgName;
    private String sigAlgOID;
    private Map<String, Entry> challenges;


    private CertificateInfo(DomainRequest domainRequest, String status) {
        this.status = status;
        this.domainRequest = domainRequest;
    }

    public CertificateInfo(DomainRequest domainRequest, Certificate certificate, Map<String, Entry> challenges,
                           String status) {
        this(domainRequest, status);

        if (certificate != null && certificate.getCertificate() != null) {
            this.notAfter = certificate.getCertificate().getNotAfter();
            this.notBefore = certificate.getCertificate().getNotAfter();
            this.serialNumber = certificate.getCertificate().getSerialNumber();
            this.version = certificate.getCertificate().getVersion();
            this.sigAlgName = certificate.getCertificate().getSigAlgName();
            this.sigAlgOID = certificate.getCertificate().getSigAlgOID();
        }

        this.challenges = challenges;
    }

    public static CertificateInfo from(DomainRequest domainRequest, String status) {
        return new CertificateInfo(domainRequest, status);
    }
}
