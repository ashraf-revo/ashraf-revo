package com.uxplore.certificatemanager.service.impl;

import com.uxplore.certificatemanager.domain.CertificateInfo;
import com.uxplore.certificatemanager.domain.DomainRequest;
import com.uxplore.certificatemanager.domain.Entry;
import com.uxplore.certificatemanager.service.AcmeManagerService;
import com.uxplore.certificatemanager.service.S3Service;
import org.shredzone.acme4j.*;
import org.shredzone.acme4j.challenge.Challenge;
import org.shredzone.acme4j.challenge.Dns01Challenge;
import org.shredzone.acme4j.challenge.Http01Challenge;
import org.shredzone.acme4j.challenge.TlsAlpn01Challenge;
import org.shredzone.acme4j.exception.AcmeException;
import org.shredzone.acme4j.util.CSRBuilder;
import org.shredzone.acme4j.util.KeyPairUtils;
import org.springframework.stereotype.Service;

import java.io.*;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.KeyPair;
import java.util.AbstractMap;
import java.util.HashMap;
import java.util.Map;
import java.util.function.BiConsumer;
import java.util.function.Supplier;

import static org.apache.commons.codec.binary.Hex.encodeHexString;

@Service
public class AcmeManagerServiceImpl implements AcmeManagerService {
    private final Account account;
    private final Login login;
    private final S3Service s3Service;

    public AcmeManagerServiceImpl(Account account, Login login, S3Service s3Service) {
        this.account = account;
        this.login = login;
        this.s3Service = s3Service;

    }


    @Override
    public Order order(DomainRequest domainRequest) throws AcmeException, IOException {
        Order order = this.account.newOrder().domains(domainRequest.getDomain()).create();
        generateOrGetDomainKeyPair(domainRequest);
        return order;
    }

    @Override
    public Map.Entry<String, Status> validate(URL location, String type) throws AcmeException {
        Order order = this.login.bindOrder(location);
        Authorization authorization = order.getAuthorizations().stream().findFirst().orElseThrow();
        Challenge challenge = authorization.findChallenge(type);
        String prefix = (authorization.isWildcard() ? "*." : "") + authorization.getIdentifier().getDomain();
        if (challenge != null) {
            if (challenge.getStatus() == Status.PENDING)
                challenge.trigger();
            tryUntilTrue(5, () -> {
                try {
                    if (challenge.getStatus().equals(Status.VALID)) return true;
                    Thread.sleep(3000L);
                    challenge.update();
                    return challenge.getStatus().equals(Status.VALID);
                } catch (Exception e) {
                    return false;
                }
            });
            return new AbstractMap.SimpleEntry<>(prefix, challenge.getStatus());
        }
        return new AbstractMap.SimpleEntry<>(prefix, Status.INVALID);
    }

    private CSRBuilder generateCsr(KeyPair keyPair, DomainRequest domainRequest) throws IOException {
        CSRBuilder csrBuilder = new CSRBuilder();
        csrBuilder.addDomains(domainRequest.getDomain());
        csrBuilder.sign(keyPair);
        return csrBuilder;
    }

    @Override
    public CertificateInfo generate(DomainRequest domainRequest, URL location, BiConsumer<File, String> writer) throws IOException, AcmeException {
        Order order = this.login.bindOrder(location);
        KeyPair domainKeyPair = generateOrGetDomainKeyPair(domainRequest);
        CSRBuilder csrBuilder = generateCsr(domainKeyPair, domainRequest);
        File domainCsr = Files.createTempFile("domain", ".csr").toFile();
        FileWriter csrFileWriter = new FileWriter(domainCsr);
        csrBuilder.write(csrFileWriter);
        writer.accept(domainCsr, Paths.get(domainRequest.hashCode() + "", "domain.csr").toString());
        order.execute(csrBuilder.getEncoded());
        tryUntilTrue(10, () -> {
            try {
                order.update();
                if (order.getStatus().equals(Status.VALID)) return true;
                Thread.sleep(1000);
                return order.getStatus().equals(Status.VALID);
            } catch (Exception e) {
                return false;
            }
        });

        if (order.getStatus() == Status.VALID) {
            Certificate certificate = order.getCertificate();
            if (certificate != null) {
                File domainCrt = Files.createTempFile("domain", ".crt").toFile();
                try (FileWriter crtFileWriter = new FileWriter(domainCrt)) {
                    certificate.writeCertificate(crtFileWriter);
                }
                writer.accept(domainCrt, Paths.get(domainRequest.hashCode() + "", "domain.crt").toString());
                return new CertificateInfo(domainRequest, certificate, getChallenges(domainRequest, order),
                        order.getStatus().name());
            }
        }
        return CertificateInfo.from(domainRequest, order.getStatus().name());
    }

    @Override
    public KeyPair generateOrGetDomainKeyPair(DomainRequest domainRequest) throws IOException {
        Path domainKey = Paths.get(domainRequest.hashCode() + "", "domain.key");
        if (s3Service.checkExist(domainKey.toString())) {
            InputStream stream = s3Service.getFile(domainKey.toString());
            return KeyPairUtils.readKeyPair(new InputStreamReader(stream));
        } else {
            KeyPair domainKeyPair = KeyPairUtils.createKeyPair(2048);
            Path domain = Files.createTempFile("domain", ".key");
            FileWriter fileWriter = new FileWriter(domain.toFile());
            KeyPairUtils.writeKeyPair(domainKeyPair, fileWriter);
            s3Service.uploadFile(domain.toFile(), domainKey.toString());
            return domainKeyPair;
        }
    }

    @Override
    public CertificateInfo info(DomainRequest domainRequest) {
        Order order = this.login.bindOrder(domainRequest.getLocation());
        return new CertificateInfo(domainRequest, order.getCertificate(), getChallenges(domainRequest, order),
                order.getStatus().name());
    }

    private static <T> void tryUntilTrue(int tries, Supplier<Boolean> tPredicate) {
        int localTries = tries;
        while (localTries > 1 && !tPredicate.get()) {
            localTries--;
        }
    }

    public static Map<String, Entry> getChallenges(DomainRequest domainRequest,
                                                   Order order) {
        Authorization authorization = order.getAuthorizations().stream().findFirst().orElseThrow();
        Map<String, Entry> challenges = new HashMap<>();

        Dns01Challenge dns01Challenge = authorization.findChallenge(Dns01Challenge.TYPE);
        if (dns01Challenge != null) {
            challenges.put(Dns01Challenge.TYPE, new Entry(String.format("_acme-challenge.%s",
                    authorization.getIdentifier().getDomain()), dns01Challenge.getDigest()));
        }

        Http01Challenge http01Challenge = authorization.findChallenge(Http01Challenge.TYPE);
        if (http01Challenge != null) {
            String key = String.format("http://%s/.well-known/acme-challenge/%s",
                    authorization.getIdentifier().getDomain(), http01Challenge.getToken());
            challenges.put(Http01Challenge.TYPE, new Entry(key,
                    http01Challenge.getAuthorization()));
        }

        TlsAlpn01Challenge tlsAlpn01Challenge = authorization.findChallenge(TlsAlpn01Challenge.TYPE);
        if (tlsAlpn01Challenge != null) {
            challenges.put(TlsAlpn01Challenge.TYPE, new Entry(domainRequest.getDomain(),
                    encodeHexString(tlsAlpn01Challenge.getAcmeValidation())));
        }
        return challenges;
    }

}
