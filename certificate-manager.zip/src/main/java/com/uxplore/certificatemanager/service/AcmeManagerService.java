package com.uxplore.certificatemanager.service;

import com.uxplore.certificatemanager.domain.CertificateInfo;
import com.uxplore.certificatemanager.domain.DomainRequest;
import org.shredzone.acme4j.Order;
import org.shredzone.acme4j.Status;
import org.shredzone.acme4j.exception.AcmeException;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.security.KeyPair;
import java.util.Map;
import java.util.function.BiConsumer;

public interface AcmeManagerService {
    Order order(DomainRequest domainRequest) throws AcmeException, IOException;

    Map.Entry<String, Status> validate(URL location, String type) throws AcmeException;

    CertificateInfo generate(DomainRequest domainRequest, URL location, BiConsumer<File, String> writer) throws IOException,
            AcmeException;

    KeyPair generateOrGetDomainKeyPair(DomainRequest domainRequest) throws IOException;

    CertificateInfo info(DomainRequest domainRequest);
}
